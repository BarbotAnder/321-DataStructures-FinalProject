
public class DNA 
{
	public static final int A = 0; //00 
	public static final int T = 3; //11
	public static final int C = 1; //01
	public static final int G = 2; //10
}
